Read me.

1. Using Python3 to complete project2

2. Individual work

3. Run in terminal directly and it will should the results of sample questions.

	python project2_1 

	python project2_2

4.I use basic model checking to complete the first five questions and use DPLL(Advanced Propositional Inference) to complete first four questions


Result summary:

1.Basic model checking

Question1:
Q : True


Question2:
P12 : False


Question3:
MY : not sure
MA : True
HO : True


Question4(a):
A : False
B : False
C : True


Question4(b):
A : True
B : False
C : False


Question5:
A : False
B : False
C : False
D : False
E : False
F : False
G : False
H : False
I : False
J : True
K : True
L : False

2.DPLL

Question1:
Q : True


Question2:
P12 : False


Question3:
MY : not sure
MA : True
HO : True


Question4(a):
A : False
B : False
C : True


Question4(b):
A : True
B : False
C : False

